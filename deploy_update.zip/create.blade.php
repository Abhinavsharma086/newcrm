@extends('layouts.admin')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Create Quotation</h3>
                </div>
                <div class="card-body">
                    <form action="{{ route('admin.quotations.store') }}" method="POST" id="quotationForm">
                        @csrf
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="quotation_no" class="form-label">Quotation No</label>
                                    <input type="text" class="form-control" value="{{ $quotationNo }}" disabled>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="customer_name" class="form-label">Customer <span class="text-danger">*</span></label>
                                    <select class="form-select select2-tags @error('customer_name') is-invalid @enderror" id="customer_name" name="customer_name" required>
                                        <option value="">Select Customer or Type Below</option>
                                        @foreach($customers as $customer)
                                            <option value="{{ $customer->name }}" data-gstin="{{ $customer->gstin }}" {{ old('customer_name') == $customer->name ? 'selected' : '' }}>
                                                {{ $customer->name }} {{ $customer->company_name ? '(' . $customer->company_name . ')' : '' }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('customer_name')
                                        <div class="invalid-feedback d-block">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="mb-3 position-relative">
                                    <label for="customer_gstin" class="form-label">Customer GST No. (Optional)</label>
                                    <input type="text" class="form-control @error('customer_gstin') is-invalid @enderror" id="customer_gstin" name="customer_gstin" value="{{ old('customer_gstin') }}" placeholder="Enter GSTIN (15 chars)" maxlength="15">
                                    <div id="gstSpinner" class="spinner-border spinner-border-sm text-primary position-absolute d-none" role="status" style="right: 10px; top: 38px;">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                    @error('customer_gstin')
                                        <div class="invalid-feedback d-block">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="date" class="form-label">Quotation Date <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control @error('date') is-invalid @enderror" 
                                           id="date" name="date" value="{{ old('date', date('Y-m-d')) }}" required>
                                    @error('date')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="valid_till" class="form-label">Valid Till <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <select class="form-select" id="validity_days" style="max-width: 130px;">
                                            <option value="">Custom</option>
                                            <option value="3">3 Days</option>
                                            <option value="7">7 Days</option>
                                            <option value="15">15 Days</option>
                                            <option value="30">30 Days</option>
                                        </select>
                                        <input type="date" class="form-control @error('valid_till') is-invalid @enderror" 
                                               id="valid_till" name="valid_till" value="{{ old('valid_till') }}" required>
                                    </div>
                                    @error('valid_till')
                                        <div class="invalid-feedback d-block">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <h5>Quotation Items</h5>
                            <table class="table table-bordered" id="itemsTable">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th width="100px">Quantity</th>
                                        <th width="120px">Unit Price</th>
                                        <th width="120px">Amount</th>
                                        <th width="50px"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="item-row">
                                        <td>
                                            <select class="form-select select2-tags product-select mb-2" name="items[0][product_name]" required>
                                                <option value="">Select Product or Type Below</option>
                                                @foreach($products as $product)
                                                    <option value="{{ $product->name }}" data-price="{{ $product->price }}">
                                                        {{ $product->name }} {{ $product->sku ? '(' . $product->sku . ')' : '' }}
                                                    </option>
                                                @endforeach
                                            </select>
                                        </td>
                                        <td>
                                            <input type="number" class="form-control quantity" name="items[0][quantity]" value="1" min="1" required>
                                        </td>
                                        <td>
                                            <input type="number" step="0.01" class="form-control unit-price" name="items[0][unit_price]" value="0" required>
                                        </td>
                                        <td>
                                            <input type="text" class="form-control amount" readonly value="0.00">
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-danger btn-sm remove-row">×</button>
                                        </td>
                                    </tr>
                                </tbody>

                            </table>
                            <button type="button" class="btn btn-secondary btn-sm" id="addRow">Add Item</button>
                        </div>

                        <div class="mb-3">
                            <label for="notes" class="form-label">Notes</label>
                            <textarea class="form-control @error('notes') is-invalid @enderror" 
                                      id="notes" name="notes" rows="3">{{ old('notes') }}</textarea>
                            @error('notes')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="d-flex justify-content-between">
                            <a href="{{ route('admin.quotations.index') }}" class="btn btn-secondary">Cancel</a>
                            <button type="submit" class="btn btn-primary">Create Quotation</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let rowIndex = 1;

document.getElementById('addRow').addEventListener('click', function() {
    const tbody = document.querySelector('#itemsTable tbody');
    const newRow = document.querySelector('.item-row').cloneNode(true);
    
    newRow.querySelectorAll('select, input').forEach(el => {
        const name = el.getAttribute('name');
        if (name) {
            el.setAttribute('name', name.replace(/\[\d+\]/, '[' + rowIndex + ']'));
        }
        if (el.classList.contains('quantity')) el.value = 1;
        if (el.classList.contains('unit-price')) el.value = 0;
        if (el.classList.contains('amount')) el.value = '0.00';
        if (el.tagName === 'SELECT') {
            $(el).val('').trigger('change.select2');
        }
    });
    
    tbody.appendChild(newRow);
    
    // Re-initialize select2 on the new row
    $(newRow).find('.select2-tags').select2({
        theme: 'bootstrap-5',
        tags: true,
        placeholder: "Select or Type Below",
        allowClear: true
    });
    
    rowIndex++;
});

document.addEventListener('click', function(e) {
    if (e.target.classList.contains('remove-row')) {
        if (document.querySelectorAll('.item-row').length > 1) {
            e.target.closest('.item-row').remove();
        }
    }
});

// Auto-fill GSTIN for customer
$(document).on('change', '#customer_name', function(e) {
    if (this.selectedIndex > -1) {
        const gstin = this.options[this.selectedIndex].dataset.gstin || '';
        document.getElementById('customer_gstin').value = gstin;
    } else {
        document.getElementById('customer_gstin').value = '';
    }
});

// Auto-fetch Customer Name by GSTIN
document.getElementById('customer_gstin').addEventListener('input', function() {
    const gstin = this.value.toUpperCase();
    this.value = gstin;
    
    if (gstin.length === 15) {
        const spinner = document.getElementById('gstSpinner');
        spinner.classList.remove('d-none');
        
        fetch(`/admin/api/verify-gstin/${gstin}`)
            .then(response => response.json())
            .then(data => {
                spinner.classList.add('d-none');
                if (data.success && data.data) {
                    const companyName = data.data.company_name;
                    const select = $('#customer_name');
                    
                    // Check if option exists
                    if (select.find("option[value='" + companyName + "']").length) {
                        select.val(companyName).trigger('change');
                    } else { 
                        // Create new option
                        const newOption = new Option(companyName, companyName, true, true);
                        newOption.dataset.gstin = gstin;
                        select.append(newOption).trigger('change');
                    }
                }
            })
            .catch(error => {
                spinner.classList.add('d-none');
                console.error('Error fetching GST details:', error);
            });
    }
});

// Valid Till Days dropdown logic
document.getElementById('validity_days').addEventListener('change', function() {
    const days = parseInt(this.value);
    const dateInput = document.getElementById('date').value;
    
    if (days && dateInput) {
        const date = new Date(dateInput);
        date.setDate(date.getDate() + days);
        document.getElementById('valid_till').value = date.toISOString().split('T')[0];
    }
});

// If valid_till is manually changed, set dropdown to Custom
document.getElementById('valid_till').addEventListener('input', function() {
    document.getElementById('validity_days').value = '';
});

// Also update valid_till when quotation date changes if a predefined option is selected
document.getElementById('date').addEventListener('change', function() {
    const dropdown = document.getElementById('validity_days');
    if (dropdown.value) {
        dropdown.dispatchEvent(new Event('change'));
    }
});

// Update JS event listener for select2
$(document).on('change', '.product-select', function(e) {
    const row = $(this).closest('.item-row')[0];
    let price = 0;
    
    // If it's an existing option selected
    if (this.selectedIndex > -1) {
        price = this.options[this.selectedIndex].dataset.price || 0;
    }
    
    row.querySelector('.unit-price').value = price;
    updateRowAmount(row);
});

document.addEventListener('input', function(e) {
    if (e.target.classList.contains('quantity') || e.target.classList.contains('unit-price')) {
        updateRowAmount(e.target.closest('.item-row'));
    }
});

function updateRowAmount(row) {
    const qty = parseFloat(row.querySelector('.quantity').value) || 0;
    const price = parseFloat(row.querySelector('.unit-price').value) || 0;
    const amount = qty * price;
    row.querySelector('.amount').value = amount.toFixed(2);
}
</script>
@endsection
