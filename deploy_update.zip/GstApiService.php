<?php

namespace App\Services;

class GstApiService
{
    /**
     * Verify a GSTIN and return taxpayer details.
     * 
     * @param string $gstin
     * @return array|null
     */
    public function verifyGstin(string $gstin)
    {
        // For production, you would make an HTTP request here to Razorpay, ClearTax, etc.
        // Example:
        // $response = Http::withHeaders(['X-Api-Key' => env('GST_API_KEY')])->get("https://api.provider.com/v1/gstin/{$gstin}");
        // if ($response->successful()) { return $response->json(); }
        
        // Mock implementation for demonstration
        if (strlen($gstin) !== 15) {
            return null;
        }

        // Simulate network delay
        sleep(1);

        // Dummy data generator based on GSTIN
        $stateCode = substr($gstin, 0, 2);
        
        $states = [
            '27' => 'Maharashtra',
            '07' => 'Delhi',
            '29' => 'Karnataka',
            '24' => 'Gujarat',
            '33' => 'Tamil Nadu'
        ];
        
        $state = $states[$stateCode] ?? 'Other State';
        
        return [
            'gstin' => $gstin,
            'legal_name' => 'Demo Enterprise ' . substr($gstin, 2, 4),
            'trade_name' => 'Demo Store (' . substr($gstin, -4) . ')',
            'status' => 'Active',
            'address' => '123 Fake Street, Business Park',
            'city' => 'Metropolis',
            'state' => $state,
            'zip' => '400001'
        ];
    }
}
