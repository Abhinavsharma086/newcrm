<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\Product;
use App\Models\Quotation;
use App\Services\GstCalculationService;
use App\Services\InvoiceService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Barryvdh\DomPDF\Facade\Pdf;

class QuotationController extends Controller
{
    public function index()
    {
        $quotations = Quotation::with('customer')->latest()->get();
        return view('admin.quotations.index', compact('quotations'));
    }

    public function create()
    {
        $customers = Customer::all();
        $products = Product::all();
        $quotationNo = $this->generateQuotationNumber();
        
        return view('admin.quotations.create', compact('customers', 'products', 'quotationNo'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'customer_name' => 'required|string|max:255',
            'customer_gstin' => 'nullable|string|max:20',
            'date' => 'required|date',
            'valid_till' => 'required|date|after_or_equal:date',
            'notes' => 'nullable|string',
            'items.*.product_name' => 'required|string|max:255',
            'items.*.quantity' => 'required|integer|min:1',
            'items.*.unit_price' => 'required|numeric|min:0',
        ]);

        $customerName = $validated['customer_name'];
        $customerGstin = $validated['customer_gstin'] ?? null;
        $customer = Customer::firstOrCreate(
            ['name' => $customerName],
            ['phone' => '0000000000', 'source' => 'manual', 'gstin' => $customerGstin]
        );
        
        // Update GSTIN if provided and different
        if (!empty($customerGstin) && $customer->gstin !== $customerGstin) {
            $customer->update(['gstin' => $customerGstin]);
        }
        
        $customerId = $customer->id;

        DB::transaction(function () use ($validated, $customerId) {
            $quotation = Quotation::create([
                'quotation_no' => $this->generateQuotationNumber(),
                'customer_id' => $customerId,
                'date' => $validated['date'],
                'valid_till' => $validated['valid_till'],
                'notes' => $validated['notes'],
                'created_by' => auth()->id(),
            ]);

            $subtotal = 0;
            $taxAmount = 0;

            foreach ($validated['items'] as $item) {
                $productName = $item['product_name'];
                $product = Product::where('name', $productName)->first();
                
                if ($product) {
                    $description = $product->name;
                    $taxRate = $product->tax_rate;
                    $productId = $product->id;
                } else {
                    $description = $productName;
                    $taxRate = 0; // Default tax for manual items
                    $productId = null;
                }
                
                $lineTotal = $item['quantity'] * $item['unit_price'];
                $lineTax = ($lineTotal * $taxRate) / 100;

                $quotation->items()->create([
                    'product_id' => $productId,
                    'description' => $description,
                    'quantity' => $item['quantity'],
                    'unit_price' => $item['unit_price'],
                    'tax_rate' => $taxRate,
                    'tax_amount' => $lineTax,
                    'total' => $lineTotal + $lineTax,
                ]);

                $subtotal += $lineTotal;
                $taxAmount += $lineTax;
            }

            $quotation->update([
                'subtotal' => $subtotal,
                'tax_amount' => $taxAmount,
                'total' => $subtotal + $taxAmount,
            ]);
        });

        return redirect()->route('admin.quotations.index')->with('success', 'Quotation created successfully');
    }

    public function show(Quotation $quotation)
    {
        $quotation->load('customer', 'items.product');
        return view('admin.quotations.show', compact('quotation'));
    }

    public function edit(Quotation $quotation)
    {
        $customers = Customer::all();
        $products = Product::all();
        $quotation->load('items');
        
        return view('admin.quotations.edit', compact('quotation', 'customers', 'products'));
    }

    public function update(Request $request, Quotation $quotation)
    {
        $validated = $request->validate([
            'status' => 'required|in:draft,sent,accepted,rejected',
        ]);

        $quotation->update($validated);

        return redirect()->route('admin.quotations.show', $quotation)->with('success', 'Quotation updated successfully');
    }

    public function destroy(Quotation $quotation)
    {
        $quotation->delete();
        return redirect()->route('admin.quotations.index')->with('success', 'Quotation deleted successfully');
    }

    public function downloadPdf(Quotation $quotation)
    {
        $quotation->load('customer', 'items.product');
        $pdf = Pdf::loadView('admin.quotations.pdf', compact('quotation'));
        return $pdf->download('quotation-' . $quotation->quotation_no . '.pdf');
    }

    public function convertToInvoice(Quotation $quotation)
    {
        if ($quotation->invoices()->exists()) {
            return redirect()->route('admin.quotations.show', $quotation)
                ->with('error', 'This quotation has already been converted to an invoice.');
        }

        $gstService = app(GstCalculationService::class);
        $invoiceService = app(InvoiceService::class);
        $companyState = config('app.company_state', 'Delhi');
        $customerState = $quotation->customer->state ?? $companyState;

        return DB::transaction(function () use ($quotation, $gstService, $invoiceService, $companyState, $customerState) {
            // Generate invoice number
            $invoiceNo = $invoiceService->generateInvoiceNumber();

            $invoice = Invoice::create([
                'invoice_no'     => $invoiceNo,
                'customer_id'    => $quotation->customer_id,
                'quotation_id'   => $quotation->id,
                'invoice_date'   => now()->toDateString(),
                'due_date'       => now()->addDays(30)->toDateString(),
                'notes'          => $quotation->notes,
                'payment_status' => 'unpaid',
                'paid_amount'    => 0,
                'created_by'     => auth()->id(),
            ]);

            $subtotal = 0; $cgstTotal = 0; $sgstTotal = 0; $igstTotal = 0;

            foreach ($quotation->items as $qItem) {
                $product   = $qItem->product;
                $taxRate   = $qItem->tax_rate ?? ($product ? $product->tax_rate : 0);
                $lineTotal = $qItem->quantity * $qItem->unit_price;
                $gst       = $gstService->calculateGst($lineTotal, $taxRate, $customerState, $companyState);

                InvoiceItem::create([
                    'invoice_id'   => $invoice->id,
                    'product_id'   => $qItem->product_id,
                    'description'  => $qItem->description,
                    'hsn_code'     => $product ? $product->hsn_code : null,
                    'quantity'     => $qItem->quantity,
                    'unit'         => $product ? $product->unit : null,
                    'unit_price'   => $qItem->unit_price,
                    'tax_rate'     => $taxRate,
                    'cgst'         => $gst['cgst'],
                    'sgst'         => $gst['sgst'],
                    'igst'         => $gst['igst'],
                    'total'        => $lineTotal + $gst['total_tax'],
                ]);

                $subtotal   += $lineTotal;
                $cgstTotal  += $gst['cgst'];
                $sgstTotal  += $gst['sgst'];
                $igstTotal  += $gst['igst'];
            }

            $invoice->update([
                'subtotal' => $subtotal,
                'cgst'     => $cgstTotal,
                'sgst'     => $sgstTotal,
                'igst'     => $igstTotal,
                'total'    => $subtotal + $cgstTotal + $sgstTotal + $igstTotal,
            ]);

            // Mark quotation as accepted
            $quotation->update(['status' => 'accepted']);

            return redirect()->route('admin.invoices.show', $invoice)
                ->with('success', 'Quotation converted to Invoice #' . $invoiceNo . ' successfully!');
        });
    }

    private function generateQuotationNumber()
    {
        $year = date('Y');
        $month = date('m');
        $prefix = "QUO-{$year}{$month}-";
        
        $lastQuotation = Quotation::where('quotation_no', 'like', $prefix . '%')
            ->orderBy('quotation_no', 'desc')
            ->first();
        
        if ($lastQuotation) {
            $lastNumber = (int) substr($lastQuotation->quotation_no, -4);
            $newNumber = $lastNumber + 1;
        } else {
            $newNumber = 1;
        }
        
        return $prefix . str_pad($newNumber, 4, '0', STR_PAD_LEFT);
    }
}
