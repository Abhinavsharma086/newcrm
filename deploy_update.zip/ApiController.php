<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Services\GstApiService;
use Illuminate\Http\Request;

class ApiController extends Controller
{
    public function verifyGstin(Request $request, $gstin, GstApiService $gstService)
    {
        // Check if customer already exists in local DB
        $customer = Customer::where('gstin', $gstin)->first();
        
        if ($customer) {
            return response()->json([
                'success' => true,
                'source' => 'local',
                'data' => [
                    'company_name' => $customer->company_name ?? $customer->name,
                    'trade_name' => $customer->company_name ?? $customer->name,
                    'address' => $customer->address,
                    'city' => $customer->city,
                    'state' => $customer->state,
                    'zip' => $customer->zip,
                ]
            ]);
        }

        // If not in local DB, fetch from GST API
        $gstDetails = $gstService->verifyGstin($gstin);

        if ($gstDetails) {
            return response()->json([
                'success' => true,
                'source' => 'api',
                'data' => [
                    'company_name' => $gstDetails['trade_name'],
                    'trade_name' => $gstDetails['trade_name'],
                    'legal_name' => $gstDetails['legal_name'],
                    'address' => $gstDetails['address'],
                    'city' => $gstDetails['city'],
                    'state' => $gstDetails['state'],
                    'zip' => $gstDetails['zip'],
                ]
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Invalid GSTIN or unable to fetch details.'
        ], 404);
    }
}
