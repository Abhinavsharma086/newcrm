@extends('layouts.admin')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h3 class="card-title">Quotation #{{ $quotation->quotation_no }}</h3>
                    <div>
                        <a href="{{ route('admin.quotations.pdf', $quotation) }}" class="btn btn-info btn-sm" target="_blank">
                            <i class="fas fa-download"></i> PDF
                        </a>
                        @if($quotation->status !== 'accepted')
                            <form action="{{ route('admin.quotations.convert-to-invoice', $quotation) }}" method="POST" class="d-inline-block">
                                @csrf
                                <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-file-invoice me-1"></i>Convert to Invoice</button>
                            </form>
                        @endif
                        <a href="{{ route('admin.quotations.edit', $quotation) }}" class="btn btn-warning btn-sm">Edit</a>
                        <a href="{{ route('admin.quotations.index') }}" class="btn btn-secondary btn-sm">Back</a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h5>Customer Details</h5>
                            <p>
                                <strong>{{ $quotation->customer->name }}</strong><br>
                                {{ $quotation->customer->company_name }}<br>
                                {{ $quotation->customer->address }}<br>
                                Email: {{ $quotation->customer->email }}<br>
                                Phone: {{ $quotation->customer->phone }}<br>
                                @if($quotation->customer->gstin)
                                <strong>GSTIN:</strong> {{ $quotation->customer->gstin }}
                                @endif
                            </p>
                        </div>
                        <div class="col-md-6 text-end">
                            <p>
                                <strong>Date:</strong> {{ $quotation->date->format('d M Y') }}<br>
                                <strong>Valid Till:</strong> {{ $quotation->valid_till->format('d M Y') }}<br>
                                <strong>Status:</strong> 
                                <span class="badge bg-{{ $quotation->status == 'accepted' ? 'success' : ($quotation->status == 'sent' ? 'info' : ($quotation->status == 'rejected' ? 'danger' : 'secondary')) }}">
                                    {{ ucfirst($quotation->status) }}
                                </span>
                            </p>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Description</th>
                                    <th class="text-end">Quantity</th>
                                    <th class="text-end">Unit Price</th>
                                    <th class="text-end">Tax Rate</th>
                                    <th class="text-end">Tax Amount</th>
                                    <th class="text-end">Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($quotation->items as $item)
                                <tr>
                                    <td>{{ $item->product->name ?? 'N/A' }}</td>
                                    <td>{{ $item->description }}</td>
                                    <td class="text-end">{{ $item->quantity }}</td>
                                    <td class="text-end">₹{{ number_format($item->unit_price, 2) }}</td>
                                    <td class="text-end">{{ $item->tax_rate }}%</td>
                                    <td class="text-end">₹{{ number_format($item->tax_amount, 2) }}</td>
                                    <td class="text-end">₹{{ number_format($item->total, 2) }}</td>
                                </tr>
                                @endforeach
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="6" class="text-end">Subtotal:</th>
                                    <td class="text-end">₹{{ number_format($quotation->subtotal, 2) }}</td>
                                </tr>
                                <tr>
                                    <th colspan="6" class="text-end">Tax:</th>
                                    <td class="text-end">₹{{ number_format($quotation->tax_amount, 2) }}</td>
                                </tr>
                                <tr>
                                    <th colspan="6" class="text-end">Total:</th>
                                    <th class="text-end">₹{{ number_format($quotation->total, 2) }}</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                    @if($quotation->notes)
                    <div class="mt-3">
                        <strong>Notes:</strong>
                        <p>{{ $quotation->notes }}</p>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
