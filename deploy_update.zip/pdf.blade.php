<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Quotation #{{ $quotation->quotation_no }}</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 30px; }
        .quotation-details { margin-bottom: 20px; }
        .quotation-details table { width: 100%; }
        .quotation-details td { padding: 5px; }
        .items-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        .items-table th, .items-table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        .items-table th { background-color: #f2f2f2; }
        .text-right { text-align: right; }
        .totals { margin-left: auto; width: 300px; }
        .totals table { width: 100%; }
        .totals td { padding: 5px; }
        .footer { margin-top: 50px; text-align: center; font-size: 10px; color: #666; }
    </style>
</head>
<body>
    <div class="header">
        <h1>QUOTATION</h1>
        <h3>Quotation #{{ $quotation->quotation_no }}</h3>
    </div>

    <div class="quotation-details">
        <table>
            <tr>
                <td width="50%">
                    <strong>To:</strong><br>
                    {{ $quotation->customer->name }}<br>
                    {{ $quotation->customer->company_name }}<br>
                    {{ $quotation->customer->address }}<br>
                    Email: {{ $quotation->customer->email }}<br>
                    Phone: {{ $quotation->customer->phone }}<br>
                    @if($quotation->customer->gstin)
                    <strong>GSTIN:</strong> {{ $quotation->customer->gstin }}
                    @endif
                </td>
                <td width="50%" style="text-align: right;">
                    <strong>Date:</strong> {{ $quotation->date->format('d M Y') }}<br>
                    <strong>Valid Till:</strong> {{ $quotation->valid_till->format('d M Y') }}<br>
                    <strong>Status:</strong> {{ ucfirst($quotation->status) }}
                </td>
            </tr>
        </table>
    </div>

    <table class="items-table">
        <thead>
            <tr>
                <th>Product</th>
                <th>Description</th>
                <th class="text-right">Qty</th>
                <th class="text-right">Unit Price</th>
                <th class="text-right">Tax Rate</th>
                <th class="text-right">Tax Amount</th>
                <th class="text-right">Total</th>
            </tr>
        </thead>
        <tbody>
            @foreach($quotation->items as $item)
            <tr>
                <td>{{ $item->product->name ?? 'N/A' }}</td>
                <td>{{ $item->description }}</td>
                <td class="text-right">{{ $item->quantity }}</td>
                <td class="text-right">₹{{ number_format($item->unit_price, 2) }}</td>
                <td class="text-right">{{ $item->tax_rate }}%</td>
                <td class="text-right">₹{{ number_format($item->tax_amount, 2) }}</td>
                <td class="text-right">₹{{ number_format($item->total, 2) }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <div class="totals">
        <table>
            <tr>
                <td><strong>Subtotal:</strong></td>
                <td class="text-right">₹{{ number_format($quotation->subtotal, 2) }}</td>
            </tr>
            <tr>
                <td><strong>Tax:</strong></td>
                <td class="text-right">₹{{ number_format($quotation->tax_amount, 2) }}</td>
            </tr>
            <tr style="border-top: 2px solid #333;">
                <td><strong>Total:</strong></td>
                <td class="text-right"><strong>₹{{ number_format($quotation->total, 2) }}</strong></td>
            </tr>
        </table>
    </div>

    @if($quotation->notes)
    <div style="margin-top: 20px;">
        <strong>Notes:</strong><br>
        {{ $quotation->notes }}
    </div>
    @endif

    <div class="footer">
        <p>Thank you for your business!</p>
        <p>This quotation is valid until {{ $quotation->valid_till->format('d M Y') }}</p>
    </div>
</body>
</html>
