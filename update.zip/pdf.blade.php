<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Invoice #{{ $invoice->invoice_no }}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: DejaVu Sans, Arial, sans-serif; font-size: 11px; color: #222; }
        .page { padding: 20px; }

        /* Header */
        .header-table { width: 100%; border-bottom: 3px solid #1e40af; margin-bottom: 10px; }
        .header-table td { vertical-align: middle; padding: 0 0 10px 0; }
        .logo-cell { width: 180px; }
        .logo-cell img { max-height: 55px; width: auto; }
        .company-cell { text-align: center; }
        .company-name { font-size: 18px; font-weight: bold; color: #1e40af; }
        .company-sub { font-size: 10px; color: #555; }
        .invoice-title-cell { text-align: right; }
        .invoice-title { font-size: 22px; font-weight: bold; color: #1e40af; letter-spacing: 2px; }
        .invoice-no { font-size: 13px; font-weight: bold; color: #333; }

        /* Info band */
        .info-band { background: #1e40af; color: #fff; padding: 5px 10px; margin-bottom: 10px; }
        .info-band table { width: 100%; }
        .info-band td { font-size: 10px; }

        /* Bill/Ship sections */
        .address-table { width: 100%; margin-bottom: 12px; border: 1px solid #ccc; }
        .address-table td { vertical-align: top; padding: 8px; width: 50%; border: 1px solid #ccc; }
        .section-label { font-size: 9px; font-weight: bold; color: #1e40af; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 4px; }
        .addr-name { font-size: 12px; font-weight: bold; }

        /* Items table */
        .items-table { width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 10px; }
        .items-table th { background: #1e40af; color: #fff; padding: 6px 4px; text-align: center; border: 1px solid #1e40af; }
        .items-table td { border: 1px solid #ccc; padding: 5px 4px; vertical-align: middle; }
        .items-table tr:nth-child(even) td { background: #f8f9ff; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }

        /* Totals */
        .totals-section { width: 100%; }
        .totals-table { float: right; width: 280px; border-collapse: collapse; font-size: 11px; }
        .totals-table td { padding: 5px 8px; border: 1px solid #ddd; }
        .totals-table .grand-row td { background: #1e40af; color: #fff; font-weight: bold; font-size: 13px; }
        .totals-label { font-weight: bold; }

        /* Clearfix */
        .clearfix::after { content: ''; display: table; clear: both; }

        /* Notes and footer */
        .notes-section { margin-top: 15px; padding: 8px; background: #f8f9ff; border-left: 3px solid #1e40af; font-size: 10px; }
        .footer-section { margin-top: 25px; border-top: 1px solid #ccc; padding-top: 10px; }
        .footer-table { width: 100%; }
        .footer-table td { vertical-align: top; font-size: 10px; color: #555; }
        .declaration { font-size: 9px; color: #777; margin-top: 5px; }

        /* Status badge */
        .status-paid { color: green; font-weight: bold; }
        .status-unpaid { color: red; font-weight: bold; }
        .status-partial { color: orange; font-weight: bold; }

        .amount-words { font-style: italic; font-size: 10px; color: #555; margin-top: 5px; }
    </style>
</head>
<body>
<div class="page">

    <!-- Header -->
    <table class="header-table">
        <tr>
            <td class="logo-cell">
                <img src="{{ public_path('MQ logo.png') }}" alt="Logo">
            </td>
            <td class="company-cell">
                <div class="company-name">{{ config('app.company_name', 'Metric Qube Energy Pvt. Ltd.') }}</div>
                <div class="company-sub">
                    {{ config('app.company_address', 'Jaipur, Rajasthan, India') }}<br>
                    GSTIN: {{ config('app.company_gstin', '08AAACM0000A1Z5') }} | Ph: {{ config('app.company_phone', '+91 98765 43210') }}
                </div>
            </td>
            <td class="invoice-title-cell">
                <div class="invoice-title">
                    @if($invoice->invoice_type === 'proforma') PROFORMA INVOICE
                    @elseif($invoice->invoice_type === 'without_gst') BILL OF SUPPLY
                    @else TAX INVOICE
                    @endif
                </div>
                <div class="invoice-no">#{{ $invoice->invoice_no }}</div>
                <div class="company-sub">
                    Date: {{ $invoice->invoice_date->format('d-M-Y') }}<br>
                    Due: {{ $invoice->due_date->format('d-M-Y') }}<br>
                    Status: <span class="status-{{ $invoice->payment_status }}">{{ strtoupper($invoice->payment_status) }}</span>
                </div>
            </td>
        </tr>
    </table>

    <!-- Bill To -->
    <table class="address-table">
        <tr>
            <td>
                <div class="section-label">Bill To (Customer Details)</div>
                <div class="addr-name">{{ $invoice->customer->name ?? 'N/A' }}</div>
                @if($invoice->customer)
                    @if($invoice->customer->company_name)
                    <div><strong>Company:</strong> {{ $invoice->customer->company_name }}</div>
                    @endif
                    @if($invoice->customer->address)
                    <div><strong>Address:</strong> {{ $invoice->customer->address }}</div>
                    @endif
                    @if($invoice->customer->city || $invoice->customer->state || $invoice->customer->pin)
                    <div><strong>Location:</strong> {{ implode(', ', array_filter([$invoice->customer->city, $invoice->customer->state, $invoice->customer->pin])) }}</div>
                    @endif
                    @if($invoice->customer->gstin)
                    <div style="margin-top:3px; font-weight:bold; color:#1e40af;">GSTIN / GST No: {{ $invoice->customer->gstin }}</div>
                    @endif
                    @if($invoice->customer->phone)
                    <div><strong>Phone:</strong> {{ $invoice->customer->phone }}</div>
                    @endif
                    @if($invoice->customer->email)
                    <div><strong>Email:</strong> {{ $invoice->customer->email }}</div>
                    @endif
                @endif
                @if($invoice->client)
                    <div style="margin-top:6px; padding-top:4px; border-top:1px dashed #ccc;">
                        <small style="color:#666;"><strong>Client:</strong> {{ $invoice->client->name }} @if($invoice->client->phone)| Ph: {{ $invoice->client->phone }}@endif</small>
                    </div>
                @endif
            </td>
            <td>
                <div class="section-label">Invoice Details</div>
                <table style="width:100%; font-size:10px;">
                    <tr><td style="color:#555; width:45%;">Invoice No:</td><td><strong>{{ $invoice->invoice_no }}</strong></td></tr>
                    <tr><td style="color:#555;">Invoice Date:</td><td>{{ $invoice->invoice_date->format('d M Y') }}</td></tr>
                    <tr><td style="color:#555;">Due Date:</td><td>{{ $invoice->due_date->format('d M Y') }}</td></tr>
                    @if($invoice->customer && $invoice->customer->state)
                    <tr><td style="color:#555;">Place of Supply:</td><td><strong>{{ $invoice->customer->state }}</strong></td></tr>
                    @endif
                    <tr><td style="color:#555;">Payment Status:</td><td class="status-{{ $invoice->payment_status }}">{{ strtoupper($invoice->payment_status) }}</td></tr>
                </table>
            </td>
        </tr>
    </table>

    <!-- Items Table -->
    <table class="items-table">
        <thead>
            <tr>
                <th style="width:25px">#</th>
                <th style="text-align:left">Description of Goods/Services</th>
                <th style="width:60px">HSN/SAC</th>
                <th style="width:40px">Qty</th>
                <th style="width:40px">UOM</th>
                <th style="width:60px">Rate (₹)</th>
                <th style="width:45px">Disc %</th>
                <th style="width:70px">Taxable (₹)</th>
                @if($invoice->invoice_type !== 'without_gst')
                <th style="width:55px">CGST (₹)</th>
                <th style="width:55px">SGST (₹)</th>
                <th style="width:55px">IGST (₹)</th>
                @endif
                <th style="width:75px">Total (₹)</th>
            </tr>
        </thead>
        <tbody>
            @php $sno = 1; @endphp
            @foreach($invoice->items as $item)
            <tr>
                <td class="text-center">{{ $sno++ }}</td>
                <td>
                    {{ $item->description ?: ($item->product->name ?? 'N/A') }}
                    @if($item->product && $item->description) <br><small style="color:#777;">{{ $item->product->name }}</small>@endif
                </td>
                <td class="text-center">{{ $item->hsn_code ?? $item->product->hsn_code ?? '-' }}</td>
                <td class="text-right">{{ $item->quantity }}</td>
                <td class="text-center">{{ $item->unit ?? $item->product->unit ?? '-' }}</td>
                <td class="text-right">{{ number_format($item->unit_price, 2) }}</td>
                <td class="text-right">{{ $item->discount_percent ?? 0 }}%</td>
                <td class="text-right">{{ number_format($item->taxable_amount, 2) }}</td>
                @if($invoice->invoice_type !== 'without_gst')
                <td class="text-right">{{ number_format($item->cgst, 2) }}</td>
                <td class="text-right">{{ number_format($item->sgst, 2) }}</td>
                <td class="text-right">{{ number_format($item->igst, 2) }}</td>
                @endif
                <td class="text-right" style="font-weight:bold;">{{ number_format($item->total_amount, 2) }}</td>
            </tr>
            @endforeach
        </tbody>
        <tfoot>
            <tr style="background:#e8ecf8; font-weight:bold;">
                <td colspan="7" class="text-right">TOTAL</td>
                <td class="text-right">{{ number_format($invoice->subtotal, 2) }}</td>
                @if($invoice->invoice_type !== 'without_gst')
                <td class="text-right">{{ number_format($invoice->cgst, 2) }}</td>
                <td class="text-right">{{ number_format($invoice->sgst, 2) }}</td>
                <td class="text-right">{{ number_format($invoice->igst, 2) }}</td>
                @endif
                <td class="text-right">{{ number_format($invoice->total, 2) }}</td>
            </tr>
        </tfoot>
    </table>

    <!-- Totals + Notes -->
    <div class="totals-section clearfix">
        <div style="float:left; width:55%;">
            @if($invoice->notes)
            <div class="notes-section">
                <strong>Notes:</strong><br>{{ $invoice->notes }}
            </div>
            @endif
            <div class="amount-words" style="margin-top:10px;">
                <strong>Amount in Words:</strong><br>
                Indian Rupees {{ ucwords(numToWords($invoice->total ?? 0)) }} Only
            </div>
        </div>
        <table class="totals-table">
            <tr><td class="totals-label">Subtotal (Taxable):</td><td class="text-right">₹{{ number_format($invoice->subtotal, 2) }}</td></tr>
            @if($invoice->invoice_type !== 'without_gst')
            <tr><td class="totals-label">CGST:</td><td class="text-right">₹{{ number_format($invoice->cgst, 2) }}</td></tr>
            <tr><td class="totals-label">SGST:</td><td class="text-right">₹{{ number_format($invoice->sgst, 2) }}</td></tr>
            <tr><td class="totals-label">IGST:</td><td class="text-right">₹{{ number_format($invoice->igst, 2) }}</td></tr>
            @endif
            <tr class="grand-row"><td>GRAND TOTAL:</td><td class="text-right">₹{{ number_format($invoice->total, 2) }}</td></tr>
            @if($invoice->paid_amount > 0)
            <tr style="color:green;"><td>Paid:</td><td class="text-right">₹{{ number_format($invoice->paid_amount, 2) }}</td></tr>
            <tr style="color:red; font-weight:bold;"><td>Balance Due:</td><td class="text-right">₹{{ number_format($invoice->balance_due, 2) }}</td></tr>
            @endif
        </table>
    </div>

    <!-- Footer -->
    <div class="footer-section">
        <table class="footer-table">
            <tr>
                <td style="width:60%;">
                    @if(isset($invoice->include_payment_info) && $invoice->include_payment_info)
                    <div style="margin-bottom: 15px; border: 1px solid #ccc; padding: 10px; background: #fdfdfd;">
                        <div style="font-weight: bold; color: #1e40af; margin-bottom: 5px; font-size: 11px;">Payment & Bank Details</div>
                        <table style="width: 100%; border-collapse: collapse;">
                            <tr>
                                <td style="vertical-align: top; width: 60%; font-size: 10px; line-height: 1.4;">
                                    <strong>Bank Name:</strong> {{ $invoice->bank_name ?: 'N/A' }}<br>
                                    <strong>A/c Name:</strong> {{ $invoice->bank_account_name ?: 'N/A' }}<br>
                                    <strong>A/c Number:</strong> {{ $invoice->bank_account_number ?: 'N/A' }}<br>
                                    <strong>IFSC Code:</strong> {{ $invoice->bank_ifsc ?: 'N/A' }}<br>
                                    <strong>UPI ID:</strong> {{ $invoice->upi_id ?: 'N/A' }}
                                </td>
                                <td style="vertical-align: top; width: 40%; text-align: right;">
                                    @php
                                        $upiId = $invoice->upi_id ?: \App\Models\CompanySetting::get('upi_id');
                                        $payeeName = $invoice->bank_account_name ?: \App\Models\CompanySetting::get('bank_account_name', config('app.name'));
                                        $amount = $invoice->total;
                                        
                                        if ($upiId) {
                                            $qrData = "upi://pay?pa={$upiId}&pn={$payeeName}&am={$amount}&cu=INR";
                                            $qrUrl = "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=" . urlencode($qrData);
                                        } else {
                                            $qrUrl = "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=" . urlencode("UPI ID Not Set");
                                        }
                                        
                                        $qrBase64 = null;
                                        try {
                                            // Create a stream context with timeout
                                            $context = stream_context_create(['http' => ['timeout' => 5]]);
                                            $qrImage = @file_get_contents($qrUrl, false, $context);
                                            if ($qrImage) {
                                                $qrBase64 = 'data:image/png;base64,' . base64_encode($qrImage);
                                            }
                                        } catch (\Exception $e) {
                                            $qrBase64 = $qrUrl;
                                        }
                                    @endphp
                                    @if($qrBase64)
                                        <img src="{{ $qrBase64 }}" alt="UPI QR" style="width: 70px; height: 70px; border: 1px solid #ddd; padding: 2px;">
                                        <div style="font-size: 8px; margin-top: 2px; color: #666;">Scan to Pay ₹{{ number_format($amount, 2) }}</div>
                                        @if(!$upiId)
                                            <div style="font-size: 8px; color: #dc3545;">(UPI ID Not Set)</div>
                                        @endif
                                    @endif
                                </td>
                            </tr>
                        </table>
                    </div>
                    @endif
                    <div class="declaration">
                        Declaration: We declare that this invoice shows the actual price of the goods/services described and that all particulars are true and correct.
                    </div>
                </td>
                <td style="text-align:right; width:40%;">
                    <div style="margin-top:40px; border-top:1px solid #333; padding-top:5px; text-align:center; width:150px; float:right;">
                        Authorised Signatory
                    </div>
                </td>
            </tr>
        </table>
    </div>

</div>
</body>
</html>

@php
function numToWords($num) {
    $num = (int) round($num);
    $ones = ['','one','two','three','four','five','six','seven','eight','nine',
             'ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen',
             'seventeen','eighteen','nineteen'];
    $tens = ['','','twenty','thirty','forty','fifty','sixty','seventy','eighty','ninety'];
    if ($num < 20) return $ones[$num];
    if ($num < 100) return $tens[(int)($num/10)] . ($num % 10 ? ' ' . $ones[$num % 10] : '');
    if ($num < 1000) return $ones[(int)($num/100)] . ' hundred' . ($num % 100 ? ' ' . numToWords($num % 100) : '');
    if ($num < 100000) return numToWords((int)($num/1000)) . ' thousand' . ($num % 1000 ? ' ' . numToWords($num % 1000) : '');
    if ($num < 10000000) return numToWords((int)($num/100000)) . ' lakh' . ($num % 100000 ? ' ' . numToWords($num % 100000) : '');
    return numToWords((int)($num/10000000)) . ' crore' . ($num % 10000000 ? ' ' . numToWords($num % 10000000) : '');
}
@endphp
